import os
import random

import numpy


class Workload:
    counter = 0

    def __init__(
        self,
        env,
        workflow_submit_pipe,
        wf_path,
        arrival_rate,
        max_wf_number=float("inf"),
        random_seed=-1,
        debug=False,
    ):
        Workload.counter += 1
        self.id = "wl" + str(Workload.counter)
        self.env = env
        self.workflow_submit_pipe = workflow_submit_pipe
        self.workflow_path = wf_path
        self.arrival_rate = arrival_rate
        # 限制系统中同时存在的工作流数量。
        self.max_wf_number = max_wf_number
        self.debug = debug
        self.rand_seed = random_seed
        self.__submitted_wf_number = 0
        # 用于存储工作流延迟数据
        self.delays = []
        self.workflows = []

        env.process(self.__run())

    # 向工作流管道 self.workflow_submit_pipe 发送DAX的文件路径
    def __run(self):
        while self.__submitted_wf_number < self.max_wf_number:
            random.seed(self.rand_seed + self.__submitted_wf_number)
            if isinstance(self.workflow_path, list):
                wf_path = random.choice(self.workflow_path)
            elif os.path.isdir(self.workflow_path):
                if not hasattr(self, "cached_dax_files"):
                    # 如果没有缓存的文件列表，先缓存起来
                    self.cached_dax_files = [
                        f for f in os.listdir(self.workflow_path) if f[0] != "."
                    ]
                dax = random.choice(self.cached_dax_files)
                wf_path = self.workflow_path + "/" + dax
            else:
                yield self.workflow_submit_pipe.put(self.workflow_path)
                yield self.workflow_submit_pipe.put("end")
                return

            # 生成的随机时间间隔控制工作流提交的频率。这模拟了工作流在系统中被随机提交的情况。
            rand_state = numpy.random.RandomState(self.rand_seed)
            interval = rand_state.poisson(1.0 / self.arrival_rate)
            yield self.env.timeout(interval)
            self.delays.append(interval)

            if self.debug:
                print(
                    "[{:.2f} - {:10s}] workflow {} ({}) submitted. delays interval: {}".format(
                        self.env.now,
                        "Workload",
                        self.__submitted_wf_number,
                        dax,
                        interval,
                    )
                )

            self.workflows.append(wf_path)
            self.__submitted_wf_number += 1
            yield self.workflow_submit_pipe.put(wf_path)

        # 当所有工作流提交完成，发送 "end" 信号，表示不再有新的工作流提交。
        yield self.workflow_submit_pipe.put("end")

    @staticmethod
    def reset():
        Workflow.counter = 0
        Workload.counter = 0


class Workflow:
    counter = 0

    def __init__(self, tasks, files=None, path="", submit_time=0, union=False):
        Workflow.counter += 1
        self.id = "wf" + str(Workflow.counter)
        self.path = path

        self.fastest_exe_time = 0
        self.deadline_factor = 0
        self.cheapest_exe_cost = 0
        self.budget_factor = 0

        self.deadline = 0
        self.budget = 0
        self.submit_time = submit_time
        self.remained_length = 0
        self.finished_tasks = []

        self.tasks = tasks
        self.files = files
        self.exit_task = None
        self.entry_task = None

        self.cost = 0
        self.makespan = 0

        for task in tasks:
            self.remained_length += task.length
            task.setWorkflow(self)

            if len(task.pred) == 0:
                self.entry_task = task
            elif len(task.succ) == 0:
                self.exit_task = task

    def getTaskNumber(self):
        return len(self.tasks)

    @staticmethod
    def reset():
        Workflow.counter = 0
