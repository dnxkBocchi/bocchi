import random
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import datetime

from .replaybuffer import ReplayBuffer


class Network(nn.Module):
    def __init__(self, in_dim, out_dim, hidden_size, device):
        """Initialization."""
        super(Network, self).__init__()

        self.layers = nn.Sequential(
            nn.Linear(in_dim, hidden_size),
            nn.Tanh(),  # ReLU
            nn.Linear(hidden_size, hidden_size * 2),
            nn.Tanh(),  # ReLU
            nn.Linear(hidden_size * 2, hidden_size),
            nn.Tanh(),  # ReLU
            nn.Linear(hidden_size, out_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward method implementation."""
        return self.layers(x)


class DQN:
    def __init__(
        self,
        state_dim,
        action_num,
        batch_size,
        buffer_size,
        hidden_size,
        lr,
        device,
        discount_factor,
        l2_reg: float = 0,
        debug=False,
    ):

        self.action_num = action_num
        self.state_dim = state_dim
        self.buffer = ReplayBuffer(buffer_size, batch_size, device)
        self.batch_size = batch_size
        # 折扣因子γ，用于平衡未来奖励与当前奖励的重要性
        self.discount_factor = discount_factor
        self.device = device

        self.net = Network(state_dim, action_num, hidden_size, self.device).to(
            self.device
        )
        self.dqn_target_net = Network(
            state_dim, action_num, hidden_size, self.device
        ).to(self.device)
        # 将主网络 net 的权重复制到目标网络 dqn_target_net
        self.dqn_target_net.load_state_dict(self.net.state_dict())
        # 将目标网络设置为评估模式
        self.dqn_target_net.eval()

        # optimizer
        self.optimizer = torch.optim.Adam(
            self.net.parameters(), lr=lr, weight_decay=l2_reg
        )
        self.lr_scheduler = torch.optim.lr_scheduler.StepLR(
            self.optimizer, 1, gamma=0.95, last_epoch=-1, verbose=True
        )
        self.debug = debug

    def get_action(self, state, epsilon):
        # epsilon greedy policy
        # if self.net.training and self.epsilon > random.uniform(0, 1):  # [0 , 1)
        #     return random.randint(0, self.action_num - 1)
        if self.net.training and epsilon > random.uniform(0, 1):  # [0 , 1)
            return random.randint(0, self.action_num - 1)
        else:
            state = state.to(self.device)  # 将状态移动到同一设备
            action = self.net(state).argmax().detach().cpu().item()
            return action

    def computeLoss(self, samples):
        states, actions, rewards, next_states, dones = samples

        # gather 操作，基于智能体在每个状态下实际选择的动作（由 action_index 指定），
        # 计算当前状态下所采取动作的Q值
        curr_q_value = self.net(states).gather(1, actions.long())

        # DQN
        # 用于估计从当前状态转移到下一个状态后的预期回报，并根据当前奖励和未来回报更新 Q 值。
        if self.discount_factor:
            next_q_value = (
                self.dqn_target_net(next_states).max(dim=1, keepdim=True)[0].detach()
            )

            # Double DQN 改进: 使用主网络选择动作
            # next_action = self.net(next_states).argmax(dim=1, keepdim=True)
            # next_q_value = (
            #     self.dqn_target_net(next_states).gather(1, next_action).detach()
            # )
            target = (rewards + self.discount_factor * next_q_value * (1 - dones)).to(
                self.device
            )
        else:
            target = (rewards).to(self.device)
        # loss = F.mse_loss(curr_q_value, target)
        loss = F.smooth_l1_loss(curr_q_value, target)
        if self.debug:
            print("loss: ", loss.item())
        return loss

    def learn(self, example, gamma):
        loss = self.computeLoss(example)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        return loss.item()

    def save_model(self, path):
        time_str = str(datetime.datetime.now().strftime("%Y-%m-%d_%H-%M"))
        model_path = "logs/" + time_str + "/dqn_model" + path
        torch.save(self.net.state_dict(), model_path)

    def load_model(self, path):
        self.net.load_state_dict(torch.load(path))
